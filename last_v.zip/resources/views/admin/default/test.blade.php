home default currency need to be delete from system_configuration

notification
- project bid
- project Hire
- Milestone request
- Milestone Pay Payment

Home controller- select_package
Heve to delete frontend->default->select package.
